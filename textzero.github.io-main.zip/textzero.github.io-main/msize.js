setInterval(function() {
    if (window.innerWidth > 500) {
        document.getElementById("bilibujia").style.display = "flex";
    } else { document.getElementById("bilibujia").style.display = "none"; }
});